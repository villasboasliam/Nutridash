import { NextAuthOptions } from "next-auth"
import GoogleProvider from "next-auth/providers/google"
import CredentialsProvider from "next-auth/providers/credentials"
import { FirestoreAdapter } from "@next-auth/firebase-adapter"

// CORRIGIDO: Importando firestoreAdmin do Firebase Admin SDK
import { firestoreAdmin } from "@/lib/firebase-admin"
// REMOVIDO: import { doc, getDoc } from "firebase/firestore" // Estas são do Client SDK
// REMOVIDO: import { db } from "@/lib/firebase" // Este arquivo é para o Client SDK, não deve ser usado aqui

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        const { email, password } = credentials ?? {}
        if (!email || !password) {
          console.log("CredentialsProvider - Email ou senha ausentes.");
          return null;
        }

        // VERIFICAÇÃO CRÍTICA: Garante que firestoreAdmin está disponível
        if (!firestoreAdmin) {
          console.error("CredentialsProvider - Firestore Admin SDK não inicializado.");
          return null;
        }

        console.log("CredentialsProvider - Tentativa de login para o email:", email);

        try {
          // CORRIGIDO: Usando firestoreAdmin para acessar o Firestore no servidor
          const ref = firestoreAdmin.collection("nutricionistas").doc(email);
          const snap = await ref.get(); // Usar .get() para documentos do Admin SDK

          if (!snap.exists) { // Usar .exists para documentos do Admin SDK
            console.log("CredentialsProvider - Usuário não encontrado:", email);
            return null;
          }

          const user = snap.data();
          if (user?.senha !== password) {
            console.log("CredentialsProvider - Senha incorreta para:", email);
            return null;
          }

          return { id: email, name: user.nome ?? email, email };
        } catch (error: any) {
          console.error("CredentialsProvider - Erro ao autorizar:", error.message);
          return null;
        }
      },
    }),
  ],

  // O adaptador já está usando firestoreAdmin, o que está correto
  adapter: FirestoreAdapter({ firestore: firestoreAdmin! }), // Usar '!' para afirmar que não será null em runtime

  session: { strategy: "jwt" },

  pages: { signIn: "/login" },

  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === "google") {
        const email = profile?.email
        if (!email) {
          console.log("Callback signIn - Email do perfil Google ausente.");
          return false;
        }

        // VERIFICAÇÃO CRÍTICA: Garante que firestoreAdmin está disponível
        if (!firestoreAdmin) {
          console.error("Callback signIn - Firestore Admin SDK não inicializado.");
          return false;
        }

        try {
          // CORRIGIDO: Usando firestoreAdmin para acessar o Firestore no servidor
          const snap = await firestoreAdmin.collection("nutricionistas").doc(email).get();
          return snap.exists;
        } catch (error: any) {
          console.error("Callback signIn - Erro ao verificar usuário Google:", error.message);
          return false;
        }
      }
      return true
    },
    async jwt({ token, user }) {
      if (user) {
        token.uid = user.id
        token.email = user.email
      }
      return token
    },
    async session({ session, token }) {
      session.user = {
        ...(session.user || {}),
        uid: typeof token.uid === "string" ? token.uid : undefined,
        email: typeof token.email === "string" ? token.email : undefined,
      }
      return session
    },
  },
}
